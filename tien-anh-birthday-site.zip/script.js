
// Canvas shooting stars + twinkle background
const canvas = document.getElementById('space');
const ctx = canvas.getContext('2d', { alpha: true });
let W, H, stars=[], streaks=[];

function resize(){
  W = canvas.width = window.innerWidth * devicePixelRatio;
  H = canvas.height = window.innerHeight * devicePixelRatio;
}
resize();
addEventListener('resize', resize);

// Initialize stars
function initStars(n=200){
  stars = Array.from({length:n}, () => ({
    x: Math.random()*W,
    y: Math.random()*H,
    r: (Math.random()*1.8+0.2) * devicePixelRatio,
    a: Math.random()*0.6+0.2,
    t: Math.random()*360
  }));
}
initStars();

function spawnStreak(){
  const y = Math.random()*H*0.6 + H*0.1;
  const len = Math.random()*120 + 60;
  const speed = Math.random()*6 + 4;
  streaks.push({
    x: -100, y, len, speed,
    life: 0, alpha: 0.9
  });
  setTimeout(spawnStreak, Math.random()*3000+2000);
}
spawnStreak();

function draw(){
  ctx.clearRect(0,0,W,H);

  // Background nebulas
  const grad = ctx.createRadialGradient(W*0.5,H*0.6, 0, W*0.5,H*0.6, Math.max(W,H)*0.65);
  grad.addColorStop(0,'rgba(4,59,99,0.35)');
  grad.addColorStop(1,'rgba(3,26,45,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,W,H);

  // Stars
  for(const s of stars){
    s.t += 0.02;
    const flicker = (Math.sin(s.t)+1)/2 * 0.3;
    ctx.globalAlpha = s.a + flicker;
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
    ctx.fillStyle = '#9ED8FF';
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  // Shooting streaks
  ctx.lineCap = 'round';
  for(const st of streaks){
    st.x += st.speed*4*devicePixelRatio;
    st.life += 0.02;
    st.alpha = Math.max(0, 1 - st.life*0.25);
    ctx.strokeStyle = `rgba(158,216,255,${st.alpha})`;
    ctx.lineWidth = 2*devicePixelRatio;
    ctx.beginPath();
    ctx.moveTo(st.x, st.y);
    ctx.lineTo(st.x - st.len*devicePixelRatio, st.y + st.len*0.2*devicePixelRatio);
    ctx.stroke();
  }
  streaks = streaks.filter(s=> s.alpha>0 && s.x < W+200);

  requestAnimationFrame(draw);
}
draw();

// Jasmine petals
const petals = document.getElementById('petals');
function dropPetal(){
  const p = document.createElement('div');
  p.className = 'petal';
  const scale = Math.random()*0.6 + 0.7;
  const dur = Math.random()*6 + 7; // 7-13s fall
  p.style.left = Math.random()*100 + 'vw';
  p.style.animationDuration = dur+'s';
  p.style.opacity = (Math.random()*0.4 + 0.6).toFixed(2);
  p.style.transform = `scale(${scale}) rotate(${Math.random()*360}deg)`;
  petals.appendChild(p);
  setTimeout(()=> p.remove(), dur*1000);
  setTimeout(dropPetal, Math.random()*600 + 200);
}
dropPetal();

// Headline beat sync (approx): gentle scale on peaks via simple analyser if allowed
const audio = document.getElementById('bgm');
const headline = document.getElementById('headline');
const muteBtn = document.getElementById('muteBtn');
const tapHint = document.getElementById('tapHint');

async function tryAutoplay(){
  try{
    audio.volume = 0.9;
    await audio.play();
    muteBtn.classList.remove('hidden');
    muteBtn.textContent = '🔊';
  }catch(e){
    // Autoplay blocked -> show hint
    tapHint.classList.remove('hidden');
    muteBtn.classList.remove('hidden');
    muteBtn.textContent = '🔇';
  }
}
tryAutoplay();

muteBtn.addEventListener('click', async () => {
  if(audio.paused){
    try{ await audio.play(); muteBtn.textContent='🔊'; tapHint.classList.add('hidden'); }catch{}
  }else{
    audio.pause(); muteBtn.textContent='🔇';
  }
});

// Beat-ish pulse using AudioContext if allowed (fallback to CSS pulse already present).
let ctxAudio, analyser, dataArray;
function setupAnalyser(){
  try{
    ctxAudio = new (window.AudioContext || window.webkitAudioContext)();
    const source = ctxAudio.createMediaElementSource(audio);
    analyser = ctxAudio.createAnalyser();
    analyser.fftSize = 2048;
    source.connect(analyser);
    analyser.connect(ctxAudio.destination);
    dataArray = new Uint8Array(analyser.frequencyBinCount);
    requestAnimationFrame(beatTick);
  }catch(e){ /* ignore */ }
}

function beatTick(){
  if(analyser){
    analyser.getByteFrequencyData(dataArray);
    // crude energy in low-mid band
    let sum = 0;
    for(let i=4;i<24;i++) sum += dataArray[i];
    const energy = sum / 20 / 255; // 0..1
    const s = 1 + energy*0.05;
    headline.style.transform = `scale(${s})`;
  }
  requestAnimationFrame(beatTick);
}

// Unlock audio context on first user interaction (improves iOS behavior)
['pointerdown','touchstart'].forEach(evt=>{
  window.addEventListener(evt, () => {
    if(ctxAudio && ctxAudio.state === 'suspended'){ ctxAudio.resume(); }
    else if(!ctxAudio){ setupAnalyser(); }
    if(audio.paused){ audio.play().then(()=> tapHint.classList.add('hidden')).catch(()=>{}); }
  }, { once:true });
});
