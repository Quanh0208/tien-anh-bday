# Tien Anh Birthday Web (Cosmic Blue + Jasmine)
1) Đặt file **iasmine.mp3** (bản nhạc từ bài "Iasmine" của Cai Xukun) cạnh `index.html`.
   - Lưu ý bản quyền: chỉ dùng cho mục đích cá nhân.
2) Upload cả thư mục này lên GitHub Pages/Netlify/Vercel.
   - GitHub Pages: tạo repo `tien-anh-bday`, push code, bật Pages (Branch: main, Folder: /root).
   - Link sẽ là: `https://<username>.github.io/tien-anh-bday/`
3) Mở trang, kiểm tra nhạc có tự phát. Nếu bị chặn, người xem sẽ thấy nút 🔇 để bật.
4) Tạo QR: dùng file `qr_tien-anh-bday.png` (đính kèm) hoặc tạo lại với link thật của bạn.
